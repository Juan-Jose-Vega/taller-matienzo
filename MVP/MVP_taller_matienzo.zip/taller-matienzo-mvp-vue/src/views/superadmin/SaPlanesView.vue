<script setup>
import PaginationBar from '../../components/PaginationBar.vue'; import { usePaginacion } from '../../composables/usePaginacion.js';
import { reactive, ref, computed } from 'vue';
import PageHeader from '../../components/PageHeader.vue'; import AppModal from '../../components/AppModal.vue'; import FormField from '../../components/FormField.vue';
import { db } from '../../services/storageService.js'; import { usuario } from '../../services/authService.js'; import { guardarPlan, alternarPlan } from '../../services/subscriptionService.js'; import { toast } from '../../services/uiService.js'; import { money } from '../../utils/formatters.js';
const planes = computed(() => db.planes_suscripcion);
const abierto = ref(false); const f = reactive({}); const error = ref(''); let pid = null;
function abrir(p) { pid = p ? p.id : null; Object.assign(f, { nombre: p?.nombre || '', descripcion: p?.descripcion || '', importe: p?.importe || '', duracion_meses: p?.duracion_meses || 1 }); error.value = ''; abierto.value = true; }
function guardar() { const r = guardarPlan(usuario.value, f, pid); if (!r.ok) { error.value = r.error; return; } abierto.value = false; toast('Plan guardado.'); }
const pag = usePaginacion(() => planes.value, { reiniciarCon: () => [planes.value.length] });
</script>
<template>
  <PageHeader titulo="Planes de suscripción" subtitulo="Importe y duración de cada plan"><button class="btn" type="button" @click="abrir(null)">Crear plan</button></PageHeader>
  <div class="tabla-wrap"><table class="resp"><thead><tr><th>Plan</th><th>Importe</th><th>Duración</th><th>Estado</th><th></th></tr></thead><tbody><tr v-for="p in pag.items" :key="p.id"><td data-l="Plan"><b>{{ p.nombre }}</b><br><small>{{ p.descripcion }}</small></td><td data-l="Importe">{{ money(p.importe) }}</td><td data-l="Duración">{{ p.duracion_meses }} {{ p.duracion_meses === 1 ? 'mes' : 'meses' }}</td><td data-l="Estado"><span class="tag" :class="p.activo ? 't-ok' : 't-gris'">{{ p.activo ? 'Activo' : 'Inactivo' }}</span></td><td><button class="btn sec chico" type="button" @click="abrir(p)">Editar</button> <button class="btn sec chico" type="button" @click="alternarPlan(usuario, p.id)">{{ p.activo ? 'Desactivar' : 'Activar' }}</button></td></tr></tbody></table></div>
  <PaginationBar :pag="pag" />
  <p class="hint">Cambiar un plan no modifica las suscripciones ya creadas: cada cuenta conserva su importe y duración.</p>
  <AppModal v-if="abierto" titulo="Plan" @cerrar="abierto = false"><form id="fpl" novalidate @submit.prevent="guardar"><FormField v-model="f.nombre" label="Nombre" req /><FormField v-model="f.descripcion" label="Descripción" /><div class="form-grid"><FormField v-model="f.importe" label="Importe" type="number" req /><FormField v-model="f.duracion_meses" label="Duración (meses)" type="number" req /></div><div class="msg-err" role="alert">{{ error }}</div></form><template #pie><button class="btn sec" type="button" @click="abierto = false">Cancelar</button><button class="btn" type="submit" form="fpl">Guardar</button></template></AppModal>
</template>
